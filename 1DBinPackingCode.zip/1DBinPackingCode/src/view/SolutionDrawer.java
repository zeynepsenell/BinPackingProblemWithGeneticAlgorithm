package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JPanel;
import BinPacking.Bin;
import BinPacking.ItemBinArrangement;
import GeneticAlgorithm.Individual;

public class SolutionDrawer extends JPanel{
	private static final long serialVersionUID = 1L;
	private static int PANEL_WIDTH = 1000;
    private static int BIN_WIDTH = 100;
    private static int BIN_SPACING = 20;
    private static int VERTICAL_SPACING = 60;
    private static int NUMBER_OF_BINS_IN_A_ROW = PANEL_WIDTH / (BIN_WIDTH + BIN_SPACING);
    
	private Individual bestSolution;
    private List<DrawableBin> allBins;
    
    public SolutionDrawer(Individual bestSolution) {
    	this.bestSolution = bestSolution;
    	this.init();
    }
    
    private void init() {
    	Map<Integer, DrawableBin> bins = new HashMap<>();
        for (ItemBinArrangement<Integer, Integer> itemBin : bestSolution.getItemBinArrangment()) {
            if (!bins.containsKey(itemBin.getBin())) {
                bins.put(itemBin.getBin(), new DrawableBin(itemBin.getBin()));
            }
            bins.get(itemBin.getBin()).addItem(itemBin.getItem());
        }
        this.allBins = new ArrayList<>(bins.values());
        int numberOfRows = (int) 
        		Math.ceil((double) allBins.size() / NUMBER_OF_BINS_IN_A_ROW);
        int preferredHeight = numberOfRows * (BIN_WIDTH + VERTICAL_SPACING) + VERTICAL_SPACING;
        setPreferredSize(new Dimension(PANEL_WIDTH, preferredHeight));
    }

    @Override
    protected void paintComponent(Graphics g) {
        drawBins(g);
    }

    private void drawBins(Graphics g) {
    	 super.paintComponent(g);
    	 int binSize = allBins.size();
    	 int offsetX = (PANEL_WIDTH - NUMBER_OF_BINS_IN_A_ROW * (BIN_WIDTH + BIN_SPACING) + BIN_SPACING) / 2;

    	 for (int i = 0; i < binSize; i++) {
    		 DrawableBin bin = allBins.get(i);
    		 int x = offsetX + (i % NUMBER_OF_BINS_IN_A_ROW) * (BIN_WIDTH + BIN_SPACING);
    		 int y = VERTICAL_SPACING + (i / NUMBER_OF_BINS_IN_A_ROW) * (BIN_WIDTH + VERTICAL_SPACING);

    		 g.setColor(Color.BLACK);
    		 g.drawRect(x, y, BIN_WIDTH, BIN_WIDTH);
    		 
    		 int itemsHeight = 0;
    		 int usedCapacity = 0;
    		 for (Integer itemId : bin.getItems()) {
    			 g.setColor(this.generateColor(itemId));
    			 //Calculates the item hight based on it's size but propotional to the Bin capacity 
    			 //to visualize it better
    			 int itemHeight = BIN_WIDTH * Bin.searchItemWithId(itemId) / Bin.capacity; 
    			 g.fillRect(x, y + BIN_WIDTH - itemsHeight - itemHeight, BIN_WIDTH, itemHeight);
    			 g.setColor(Color.WHITE);
    			 //Draws the item id in middle of the item
    	         g.drawString(String.valueOf(itemId), x + 
    	        		 BIN_WIDTH / 2 - 5, y + BIN_WIDTH - itemsHeight - itemHeight / 2);
    	         itemsHeight += itemHeight;
    	         usedCapacity += Bin.searchItemWithId(itemId);
    		 }	
    	     g.setColor(Color.BLACK);
    	     g.drawString("Used cap.: " + usedCapacity, x, y + BIN_WIDTH + 20);
    	     g.drawString("Waste: " + (Bin.capacity - usedCapacity), x, y + BIN_WIDTH + 40);
    	 }	
    }
    
    /**
     * This method generates for every item a different color.
     * @param itemId
     * @return
     */
    private Color generateColor(int itemId) {
		 int red = 50 + (Bin.searchItemWithId(itemId) * 10) % 206;
		 int green = 50 + (Bin.searchItemWithId(itemId) * 20) % 206;
		 int blue = 50 + (Bin.searchItemWithId(itemId) * 30) % 206;
		 //This code block avoids white/whitish color, because the background of bins are white
		 if (240 < red && red < 255 
				 && 240 < green && green < 255 
				 && 240 < blue && blue < 255 ) {
			 red = 180;
			 blue = 180;
			 green = 180;
		 }
		 Color color = new Color(red, green, blue);
		 return color;
    }
}

class DrawableBin {
    private int id;
    private List<Integer> items = new ArrayList<>();

    public DrawableBin(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public List<Integer> getItems() {
        return items;
    }

    public void addItem(int item) {
        items.add(item);
    }
}

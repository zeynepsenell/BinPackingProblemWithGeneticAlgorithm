package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.filechooser.FileNameExtensionFilter;

public class BinPackingOptionsPanel extends JFrame{
	private static final long serialVersionUID = 1L;
	
	private static String POPULATION_SIZE_LABEL = "Population size:" ;
	private static String MUTATION_RATE_LABEL = "Mutation rate:" ;
	private static String CROSSOVER_RATE_LABEL = "Crossover rate:" ;
	private static String INITIALIZATION_METHODS_LABEL = "Initialization methods:" ;
	private static String SELECTION_METHODS_LABEL = "Selection methods:" ;
	private static String CROSSOVER_METHODS_LABEL = "Crossover methods:" ;
	private static String REPLACEMENT_METHODS_LABEL = "Replacement methods:" ;
	private static String FILE_PATH_LABEL = "File path: " ;
	private static String BIN_SIZE_LABEL = "Bin size: " ;
	private static String MAX_GENERATION_LABEL = "Max. generations : " ;
	private static String TITLE = "1D Bin Packing Problem - Genetic Algorithm";
	private static String OPTIONS_HEADER = "1D Bin Packing Problem - Options";
	private static String SOLUTION_HEADER = "Solution";
	private static String START_ALGORITHM = "Start Algorithm";
	
    private String[] initializationMethodsList = {"Random Initialization", "Best-Fit Initialization", "Next-Fit Initialization"};
    private String[] selectionMethodsList = { "Tournament Selection", "Roulette Wheel Selection","SUS" };
    private String[] crossoverMethodsList = { "One-Point Crossover", "Two-Point Crossover"};
    private String[] replacementMethodsList = { "Steady-State Replacement", "Elitism" };
    
	private JButton algorithmStarterButton = new JButton(START_ALGORITHM);
	private JTextField filePathField = new JTextField();
	private JTextField binSizeField = new JTextField();
	private JTextField mutationRateField = new JTextField();
	private JTextField crossoverRateField = new JTextField();
    private JTextField populationSizeField = new JTextField();
    private JTextField maxGenerationsField = new JTextField();
    
    private JComboBox<String> selectionMethods = new JComboBox<>(selectionMethodsList);
    private JComboBox<String> initalizationMethods = new JComboBox<>(initializationMethodsList);
    private JComboBox<String> crossoverMethods = new JComboBox<>(crossoverMethodsList);
    private JComboBox<String> replacementMethods = new JComboBox<>(replacementMethodsList);
    
    private JPanel solutionPanel = new JPanel();

	public BinPackingOptionsPanel(){
		java.net.URL imageURL = BinPackingOptionsPanel.class.getResource("/images/Logo.png");
        if (imageURL != null) {
        	ImageIcon icon = new ImageIcon(imageURL);
    		this.setIconImage(icon.getImage());
        }
		this.setTitle(TITLE);
		this.init();
		this.setGlassPane(this.createGlassPane());
		this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	
	private void init() {
		this.setPreferredSize(new Dimension(1400, 700));
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        JPanel optionsPanel = this.createOptionsPanel();
        
        solutionPanel.setLayout(new BorderLayout());
        solutionPanel.setPreferredSize(new Dimension(350, 700));
        solutionPanel.setBackground(Color.WHITE);
        solutionPanel.add(new JLabel(SOLUTION_HEADER), BorderLayout.NORTH);

        Color backgroundColor = new Color(53, 171, 230);
        optionsPanel.setBackground(backgroundColor);

        splitPane.setLeftComponent(solutionPanel);
        splitPane.setRightComponent(optionsPanel);
        splitPane.setDividerLocation(1000);
        
		this.setStartButtonEnabled();
		this.addKeyAdapterToFields();
		
        this.getContentPane().add(splitPane);
        this.pack();
        this.setVisible(false);
	}
	
	/**
	 * Opens a file selector that accepts only text files with application icon.
	 */
	private void openFileSelector() {
		JFileChooser fileChooser = new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter(
				"TEXT FILES", "txt", "text");
		fileChooser.setFileFilter(filter);
        int returnVal = fileChooser.showOpenDialog(this);
        if(returnVal == JFileChooser.APPROVE_OPTION) {
        	this.filePathField.setText(fileChooser.getSelectedFile().getAbsolutePath());
        }
	}
	
	/**
	 * Sets start button enabled/disabled according to text inputs.
	 */
	private void setStartButtonEnabled() {
		DocumentListener documentListener = new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
            	updateButtonState();
            }
            @Override
            public void removeUpdate(DocumentEvent e) {
            	updateButtonState();
            }
            @Override
            public void changedUpdate(DocumentEvent e) {
            	updateButtonState();
            }
            public void updateButtonState() {
        		boolean notEnabled = mutationRateField.getText().equals("") ||
        				populationSizeField.getText().equals("") ||
        				binSizeField.getText().equals("") ||
        				maxGenerationsField.getText().equals("") ||
        				filePathField.getText().equals(""); 
        		algorithmStarterButton.setEnabled(!notEnabled);
            }
        };
        crossoverRateField.getDocument().addDocumentListener(documentListener);
        mutationRateField.getDocument().addDocumentListener(documentListener);
        populationSizeField.getDocument().addDocumentListener(documentListener);
        binSizeField.getDocument().addDocumentListener(documentListener);
        filePathField.getDocument().addDocumentListener(documentListener);
        maxGenerationsField.getDocument().addDocumentListener(documentListener);
	}
	
	/**
	 * Adds a key adapter to fields.
	 */
	private void addKeyAdapterToFields() {
		this.acceptOnlyNumbers(populationSizeField);
		this.acceptOnlyNumbers(mutationRateField);
		this.acceptOnlyNumbers(crossoverRateField);
		this.acceptOnlyNumbers(binSizeField);
		this.acceptOnlyNumbers(maxGenerationsField);
	}
	
	/**
	 * Creates a JPanel to get optional values from user
	 * @return option panel
	 */
	private JPanel createOptionsPanel() {
        JPanel panel = new JPanel();
        GroupLayout layout = new GroupLayout(panel);
        panel.setLayout(layout);
        
        //Creation of labels
		JLabel headerLabel = new JLabel(OPTIONS_HEADER);
        headerLabel.setFont(headerLabel.getFont().deriveFont(Font.CENTER_BASELINE, 16f));
       
        JLabel filePathLabel = new JLabel(FILE_PATH_LABEL);
        JLabel binHeigthLabel = new JLabel(BIN_SIZE_LABEL);
        JLabel initializationMethodsLabel = new JLabel(INITIALIZATION_METHODS_LABEL);
        JLabel selectionMethodsLabel = new JLabel(SELECTION_METHODS_LABEL);
        JLabel crossoverMethodsLabel = new JLabel(CROSSOVER_METHODS_LABEL);
        JLabel crossoverRateLabel = new JLabel(CROSSOVER_RATE_LABEL);
        JLabel replacementMethodsLabel = new JLabel(REPLACEMENT_METHODS_LABEL);
        JLabel populationSizeLabel = new JLabel(POPULATION_SIZE_LABEL);
        JLabel mutationRateLabel = new JLabel(MUTATION_RATE_LABEL);
        JLabel maxGenerationsLabel = new JLabel(MAX_GENERATION_LABEL);
        JButton selectFileButton = new JButton("Select file using FileChooser");
        
        initalizationMethods.setMaximumSize(new Dimension(210,25));
        
        selectFileButton.addActionListener(new ActionListener() { 
      	  public void actionPerformed(ActionEvent e) { 
      		  openFileSelector();
      		  }
      	  });
        
        //Assigns default values to text fields. 
        this.filePathField.setText("src/data/binpack00.txt");
        this.populationSizeField.setText("100");
        this.binSizeField.setText("150");
        this.maxGenerationsField.setText("1000");
        this.mutationRateField.setText("0.3");
        this.crossoverRateField.setText("0.7");
        
        //Fills layout
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);
        
        layout.setHorizontalGroup(
                layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(headerLabel)
                        .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                		.addComponent(filePathLabel)
                                		.addComponent(populationSizeLabel)
                                		.addComponent(binHeigthLabel)
                                		.addComponent(maxGenerationsLabel)
                                		.addComponent(selectionMethodsLabel)
                                		.addComponent(initializationMethodsLabel)
                                		.addComponent(crossoverMethodsLabel)
                                		.addComponent(replacementMethodsLabel)
                                        .addComponent(mutationRateLabel)
                                        .addComponent(crossoverRateLabel))
                                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                		.addComponent(selectFileButton)
                                		.addComponent(filePathField)
                                		.addComponent(populationSizeField)
                                		.addComponent(binSizeField)
                                		.addComponent(maxGenerationsField)
                                		.addComponent(selectionMethods)
                                		.addComponent(initalizationMethods)
                                		.addComponent(crossoverMethods)
                                		.addComponent(replacementMethods)
                                        .addComponent(mutationRateField)
                                        .addComponent(crossoverRateField)
                                        .addComponent(algorithmStarterButton)
                                        .addGroup(layout.createSequentialGroup())))
        );

        layout.setVerticalGroup(
                layout.createSequentialGroup()
                        .addComponent(headerLabel)
                        .addGap(50)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(filePathLabel)
                                .addComponent(filePathField))
                        .addGap(15)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(selectFileButton))
                        .addGap(15)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(populationSizeLabel)
                                .addComponent(populationSizeField))
                        .addGap(15)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(binHeigthLabel)
                                .addComponent(binSizeField))
                        .addGap(15)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(maxGenerationsLabel)
                                .addComponent(maxGenerationsField))
                        .addGap(15)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(selectionMethodsLabel)
                                .addComponent(selectionMethods))
                        .addGap(15)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(initializationMethodsLabel)
                                .addComponent(initalizationMethods))
                        .addGap(15)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(crossoverMethodsLabel)
                                .addComponent(crossoverMethods))

                        .addGap(15)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(replacementMethodsLabel)
                                .addComponent(replacementMethods))
                        .addGap(15)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(mutationRateLabel)
                                .addComponent(mutationRateField))
                        .addGap(15)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addComponent(crossoverRateLabel)
                                .addComponent(crossoverRateField))
                        .addGap(15)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE))
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE))
                        .addGap(50)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                        		.addComponent(algorithmStarterButton))
        );
        return panel;
	}
	
	/**
	 * Creates a GlassPane to show users that the application is running and 
	 * trying to find a solution
	 * @return created GlassPane
	 */
	JPanel createGlassPane() {
		JPanel glassPane = new JPanel() {
			private static final long serialVersionUID = 1L;
			@Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(new Color(128, 128, 128, 128));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
		glassPane.setLayout(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();
		//Constraints for adding the icon
	    constraints.gridx = 0;
	    constraints.gridy = 0;
	    constraints.anchor = GridBagConstraints.WEST;
	    constraints.insets = new Insets(0, -300, 0, 0);
	    java.net.URL imageURL = BinPackingOptionsPanel.class.getResource("/images/Loading.gif");
        if (imageURL != null) {
            ImageIcon icon = new ImageIcon(imageURL);
            JLabel loadingLabel = new JLabel(icon);
            glassPane.add(loadingLabel, constraints);
        }
        //Constraints for adding the label
        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.anchor = GridBagConstraints.WEST;
        constraints.insets = new Insets(0, -270, 0, 0);
        JLabel textLabel = new JLabel("Trying to create a solution...");
        glassPane.add(textLabel, constraints);
        glassPane.setOpaque(false); 
        return glassPane;
	} 
	
	/**
	 * Adds a key listener to given JTextField to accept only numbers.
	 * @param field
	 */
	private void acceptOnlyNumbers(JTextField field) {
		field.addKeyListener(new KeyAdapter() {
	         public void keyPressed(KeyEvent ke) {
	        	 char c = ke.getKeyChar();
	        	 if (!Character.isDigit(c) && c != KeyEvent.VK_DELETE && c != KeyEvent.VK_BACK_SPACE && c != '.') {
	        		 ke.consume();
                     field.setEditable(false);
                 }
	        	 else {
	        		 field.setEditable(true);
	            }
	         }
		});
	}

	public JButton getAlgorithmStarterButton() {
		return algorithmStarterButton;
	}

	public JTextField getBinHeightField() {
		return binSizeField;
	}
	
	public JTextField getFilePathField() {
		return filePathField;
	}

	public JTextField getMutationRateField() {
		return mutationRateField;
	}

	public JTextField getPopulationSizeField() {
		return populationSizeField;
	}

	public JTextField getMaxGenerationsField() {
		return maxGenerationsField;
	}

	public JTextField getBinSizeField() {
		return binSizeField;
	}

	public void setBinSizeField(JTextField binSizeField) {
		this.binSizeField = binSizeField;
	}

	public JComboBox<String> getInitalizationMethods() {
		return initalizationMethods;
	}

	public JComboBox<String> getSelectionMethods() {
		return selectionMethods;
	}

	public JComboBox<String> getCrossoverMethods() {
		return crossoverMethods;
	}
	
	public JTextField getCrossoverRateField() {
		return crossoverRateField;
	}

	public JComboBox<String> getReplacementMethods() {
		return replacementMethods;
	}

	public JPanel getSolutionPanel() {
		return solutionPanel;
	}
}

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicLong;

import BinPacking.Item;

public class DataReader {
	//For generating item id's.
	private AtomicLong counter = new AtomicLong(0);
	ArrayList<Item> allItems = new ArrayList<>();

	DataReader(){
		this.allItems.clear();
	}

	void readData(String pathOfFile) {
	     Path path = Paths.get(pathOfFile);
	     try (BufferedReader reader = Files.newBufferedReader(path)) {
	    	 String line;
	    	 while ((line = reader.readLine()) != null) {
	    		 int id = this.generateID();
	    		 int size = Integer.parseInt(line);
	    		 this.createAndAddItem(id, size);
	    	 }
	     } catch (IOException | NumberFormatException e) {
	    	 System.out.println("Exception caught in: " + e.getMessage());
	     }
	}
	
	private void createAndAddItem(int id, int size) {
		Item item = new Item(id, size);
		this.allItems.add(item);
	}
	
    private int generateID() {
        return (int) counter.getAndIncrement();
    }
    
	public ArrayList<Item> getAllItems() {
		return allItems;
	}

	public AtomicLong getCounter() {
		return counter;
	}

	public void setCounter(AtomicLong counter) {
		this.counter = counter;
	}
	
}

package BinPacking;

/**
 * This item class represents the "items" to be packed in 1D bin packing problem. 
 * @author zsenel
 *
 */
public class Item {
	 private int id;
	 private int size;
	 private boolean added = false;

	 public Item(int id, int size) {
		 this.id = id;
		 this.size = size;
	 }
	 
	 public void setId(int id) {
		this.id = id;
	 }
		
	 public int getId() {
		return id;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public boolean isAdded() {
		return added;
	}

	public void setAdded(boolean added) {
		this.added = added;
	}

}

package BinPacking;
/**
 * This package represent item-bin pairs in 1D Bin Packing problem. 
 * @author zsenel
 *
 * @param <I> stands for Item.
 * @param <B> stands for Bin.
 */
public class ItemBinArrangement<I, B> {
    private I item;
    private B bin;
    
    public ItemBinArrangement(I item, B bin) {
    	this.item = item;
    	this.bin = bin;
    }

    public I getItem() {
    	return item;
    }

    public void setItem(I item) {
    	this.item = item;
    }

    public B getBin() {
    	return bin;
    }

    public void setBin(B bin) {
    	this.bin = bin;
    }
}

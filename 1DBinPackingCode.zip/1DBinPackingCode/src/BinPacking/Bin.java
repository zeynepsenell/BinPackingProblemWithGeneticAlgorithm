package BinPacking;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents bins, which items will be packed into in 1D
 * Bin Packing Problem.
 * @author zsenel
 *
 */
public class Bin {
	//The capacity of bin, same for every bins in the problem that's why static
    public static int capacity;
    public static List<Item> items = new ArrayList<Item>();
    private int remainingSpace; 
    
    public Bin(int capacity) {
        Bin.capacity = capacity;
        this.remainingSpace = capacity;
    }
    
    /**
     * Adds given item to the bin if the capacity is enough.
     * @param item item to be added.
     * @return true, if item can be added.
     */
    public boolean addItem(Item item) {
        if (item.getSize() <= remainingSpace) {
            remainingSpace -= item.getSize();
            items.add(item);
            return true; 
        }
        return false;
    }
    
    public static int searchItemWithId(int itemId) {
    	for(Item item : items) {
    		if(item.getId() == itemId) {
    			return item.getSize();
    		}
    	}
    	//If fails to find item, returns -1
    	return -1;
    }
    
    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        Bin.capacity = capacity;
    }

    public int getRemainingSpace() {
        return remainingSpace;
    }

    public void setRemainingSpace(int remainingSpace) {
        this.remainingSpace = remainingSpace;
    }

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		Bin.items = items;
	}
}
package GeneticAlgorithm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import BinPacking.Bin;
import BinPacking.ItemBinArrangement;

public class Crossover {
	
	Crossover(){
		//Empty constructor to call crossover methods
	}
	
	/**
	 * Checks if with crossover created individual (given as parameter) valid.
	 * @param individual
	 * @param itemWeights
	 * @return
	 */
	boolean isIndividualValid(Individual individual, Map<Integer, Integer> itemWeights) {
	    Map<Integer, Integer> binWeights = new HashMap<>();
	    for (ItemBinArrangement<Integer, Integer> itemBinArrangment : individual.getItemBinArrangment()) {
	        int item = itemBinArrangment.getItem();
	        int bin = itemBinArrangment.getBin();
	        
	        int weightOfItem = itemWeights.get(item);
	        int currentBinWeight = binWeights.getOrDefault(bin, 0);
	        int newBinWeight = currentBinWeight + weightOfItem;
	        //If weight is bigger than the capacity, this is an invalid individual
	        if (Bin.capacity < newBinWeight) {
	            return false;
	        }
	        binWeights.put(bin, newBinWeight);
	    }
	    return true;
	}
	
	/**
	 * Performs 2 point crossover
	 * @param parent1
	 * @param parent2
	 * @return
	 */
	List<Individual> twoPointCrossover(Individual parent1, Individual parent2){
        List<ItemBinArrangement<Integer, Integer>> parent1Genes = 
        		parent1.getItemBinArrangment();
        List<ItemBinArrangement<Integer, Integer>> parent2Genes = 
        		parent2.getItemBinArrangment();
        int numberOfItems = parent1Genes.size();

        // Generate two random crossover points according to number of items
        int crossoverPoint1 = new Random().nextInt(parent1Genes.size());
        int crossoverPoint2 = new Random().nextInt(parent1Genes.size());

        // Making sure that crossoverPoint1 is smaller than crossoverPoint2
        if (crossoverPoint1 > crossoverPoint2) {
            int temp = crossoverPoint1;
            crossoverPoint1 = crossoverPoint2;
            crossoverPoint2 = temp;
        }
        //Performs crossover
        //Gets item bin arrangements/genes in parent 1 until the crossover point1.
        List<ItemBinArrangement<Integer, Integer>> offSpring1Genes 
        	= new ArrayList<>(parent1Genes.subList(0, crossoverPoint1));
        //Gets item bin arrangements/genes in parent 2 between crossoverpoint1 and 2.
        offSpring1Genes.addAll(parent2Genes.subList(crossoverPoint1, crossoverPoint2));
        //Fills the rest with item bin arrangements/genes from parent1
        offSpring1Genes.addAll(parent1Genes.subList(crossoverPoint2, numberOfItems));

        List<ItemBinArrangement<Integer, Integer>> offspring2Genes 
        	= new ArrayList<>(parent2Genes.subList(0, crossoverPoint1));
        offspring2Genes.addAll(parent1Genes.subList(crossoverPoint1, crossoverPoint2));
        offspring2Genes.addAll(parent2Genes.subList(crossoverPoint2, numberOfItems));

        Individual offspring1 = new Individual(offSpring1Genes);
        Individual offspring2 = new Individual(offspring2Genes);
        
        List<Individual> offspringIndividuals = new ArrayList<>();
        offspringIndividuals.add(offspring1);
        offspringIndividuals.add(offspring2);
        return offspringIndividuals;
    }
	
	
	/**
	 * Performs one point crossover
	 * @param parent1
	 * @param parent2
	 * @return
	 */
	List<Individual> onePointCrossover(Individual parent1, Individual parent2) {
	    List<ItemBinArrangement<Integer, Integer>> parent1Genes 
	    	= parent1.getItemBinArrangment();
	    List<ItemBinArrangement<Integer, Integer>> parent2Genes 
	    	= parent2.getItemBinArrangment();
	    int numberOfGenes = parent1Genes.size();
	    int cutPoint = new Random().nextInt(numberOfGenes);

	    List<ItemBinArrangement<Integer, Integer>> offspring1Genes = new ArrayList<>();
	    List<ItemBinArrangement<Integer, Integer>> offspring2Genes = new ArrayList<>();
	    //To keep track of items that has been added to the offsprings
	    Set<Integer> offspring1Items = new HashSet<>();
	    Set<Integer> offspring2Items = new HashSet<>();

	    //Performs crossover
	    for (int i = 0; i < numberOfGenes; i++) {
	        ItemBinArrangement<Integer, Integer> parent1Arrangement = parent1Genes.get(i);
	        ItemBinArrangement<Integer, Integer> parent2Arrangement = parent2Genes.get(i);
	        Integer itemId1 = parent1Arrangement.getItem();
	        Integer itemId2 = parent2Arrangement.getItem();
	        if (i < cutPoint) {
	        	this.addItemsOffspring(offspring1Items, itemId1, parent1Arrangement, offspring1Genes);
	        	this.addItemsOffspring(offspring2Items, itemId2, parent2Arrangement, offspring2Genes);
	        } else {
	        	this.addItemsOffspring(offspring1Items, itemId2, parent2Arrangement, offspring1Genes);
	        	this.addItemsOffspring(offspring2Items, itemId1, parent1Arrangement, offspring2Genes);
	        }
	    }

	    //Adds any missing items if there are missing items
	    for (int i = 0; i < numberOfGenes; i++) {
	        ItemBinArrangement<Integer, Integer> ItemBinArrangment1 = parent1Genes.get(i);
	        ItemBinArrangement<Integer, Integer> ItemBinArrangment2 = parent2Genes.get(i);
	        Integer itemId1 = ItemBinArrangment1.getItem();
	        Integer itemId2 = ItemBinArrangment2.getItem();
	        
	        this.addItemsOffspring(offspring1Items, itemId1, ItemBinArrangment1, offspring1Genes);
	        this.addItemsOffspring(offspring1Items, itemId2, ItemBinArrangment2, offspring1Genes);
	        this.addItemsOffspring(offspring2Items, itemId1, ItemBinArrangment1, offspring2Genes);
	        this.addItemsOffspring(offspring2Items, itemId2, ItemBinArrangment2, offspring2Genes);
	    }
	    Individual offspring1 = new Individual(offspring1Genes);
	    Individual offspring2 = new Individual(offspring2Genes);
	    List<Individual> offspring = Arrays.asList(offspring1, offspring2);
	    return offspring;
	}
	
	/**
	 * Adds any item to the bins during or after the crossover
	 * @param offspringItems
	 * @param itemId
	 * @param parentArrangement
	 * @param offspringGenes
	 */
	private void addItemsOffspring(Set<Integer> offspringItems, Integer itemId, 
			ItemBinArrangement<Integer, Integer> parentArrangement,
			List<ItemBinArrangement<Integer, Integer>> offspringGenes) {
		if (!offspringItems.contains(itemId)) {
            offspringGenes.add(parentArrangement);
            offspringItems.add(itemId);
        }
	}
	
}

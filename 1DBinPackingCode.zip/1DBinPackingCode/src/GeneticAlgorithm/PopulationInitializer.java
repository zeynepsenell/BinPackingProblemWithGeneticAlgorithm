package GeneticAlgorithm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import BinPacking.Bin;
import BinPacking.Item;
import BinPacking.ItemBinArrangement;

public class PopulationInitializer {
	
	/**
	 * Initializes the population using next fit algorithm.
	 * @param populationSize
	 * @param items
	 * @return
	 */
	static Population initializePopulationNextFit(int populationSize, List<Item> items) {
		Population population = new Population(items);
		for (int i = 0; i < populationSize; i++) {
			List<ItemBinArrangement<Integer, Integer>> itemBinArrangements = new ArrayList<>();
			List<Bin> bins = new ArrayList<>();
			Collections.shuffle(items);

			// Create the first Bin
			bins.add(new Bin(Bin.capacity));
			int currentBinIndex = 0;
		        
			for (Item item : items) {
				Bin currentBin = bins.get(currentBinIndex);
				//If item fits in the current bin, it will be added
				if (currentBin.getRemainingSpace() >= item.getSize()) {
					currentBin.addItem(item);
					itemBinArrangements.add(new ItemBinArrangement<>(item.getId(), currentBinIndex));
				} else {
					Bin newBin = new Bin(Bin.capacity);
			        bins.add(newBin);
			        currentBinIndex++;
			        if (newBin.getRemainingSpace() >= item.getSize()) {
			            newBin.addItem(item);
			            itemBinArrangements.add(new ItemBinArrangement<>(item.getId(), currentBinIndex));
			        }
				}
			}
			Individual solution = new Individual(itemBinArrangements);
			population.addIndividual(solution);
		}
		return population;		
	}
	
	/**
	 * Initializes population using best fit algorithm.
	 * @param populationSize size of the population
	 * @param items all items
	 * @return created population
	 */
	static Population initializePopulationBestFit(int populationSize, List<Item> items) {
		Population population = new Population(items);
		for (int i = 0; i < populationSize; i++) {
			List<ItemBinArrangement<Integer, Integer>> itemBinArrrangement = new ArrayList<>();
			List<Bin> bins = new ArrayList<>();
			Collections.shuffle(items);

			for (Item item : items) {
				int bestBinIndex = -1;
				int minWastedSpace = Integer.MAX_VALUE;
				
				// Iterates through all the bins to see the best bin which item can fit
				for (int bin = 0; bin < bins.size(); bin++) {
					Bin Bin = bins.get(bin);
		            int wastedSpace = Bin.getRemainingSpace() - item.getSize(); 	
		            if (wastedSpace >= 0 && wastedSpace < minWastedSpace) {
		            	bestBinIndex = bin;
		            	minWastedSpace = wastedSpace;
		            }
				}
				//If item can fit, it will be added to the bin with minimum waste
				if (bestBinIndex != -1) {
					Bin bestBin = bins.get(bestBinIndex);
					bestBin.addItem(item);
					itemBinArrrangement.add(new ItemBinArrangement<>(item.getId(), bestBinIndex));
				//If not, new bin will be created	
				} else {
					Bin newBin = new Bin(Bin.capacity);
					newBin.addItem(item);
					bins.add(newBin);
					itemBinArrrangement.add(new ItemBinArrangement<>(item.getId(), bins.size() - 1));
		        }
			}
			Individual solution = new Individual(itemBinArrrangement);
			population.addIndividual(solution);
		}
		return population;
	}
	/**
	 * Initializes first population randomly. This method may increase diversity.
	 * @param items	all items
	 * @param populationSize population size
	 * @param binCapacity capacity of bin
	 * @param probability probability of assigning an item to a existing Bin,
	 * the item might be assigned in a new Bin to increase diversity.
	 */
	static Population initializePopulationRandomly(List<Item> items,int populationSize, 
			double probabilityOfShuffling, double probabilityOfAssigning) {
		//Empty population
		Population population = new Population(items);
		for (int i = 0; i < populationSize; i++) {
			List<ItemBinArrangement<Integer, Integer>> itemBinArrangments = new ArrayList<>();
            List<Bin> bins = new ArrayList<>();
            //To increase the diversity, the items are shuffled with a probability
            if (new Random().nextDouble() > probabilityOfShuffling) {
                Collections.shuffle(items);
            }
            for (Item item : items) {
            	 item.setAdded(false);
            	 List<Integer> binIndexes = new ArrayList<>();
                 for (int binIndex = 0; binIndex < bins.size(); binIndex++) {
                     binIndexes.add(binIndex);
                 }
                 Collections.shuffle(binIndexes);
                 for (int index : binIndexes) {
                     if (new Random().nextDouble() < probabilityOfAssigning) {
                         Bin bin = bins.get(index);
                         if (bin.addItem(item)) {
                        	 itemBinArrangments.add(new ItemBinArrangement<>(item.getId(), index));
                             item.setAdded(true);
                             break;
                         }
                     }
                 }
                 if (!item.isAdded()) {
                     Bin newBin = new Bin(Bin.capacity);
                     newBin.addItem(item);
                     bins.add(newBin);
                     itemBinArrangments.add(new ItemBinArrangement<>(item.getId(), bins.size() - 1));
                 }
            }
            Individual individual = new Individual(itemBinArrangments);
            population.addIndividual(individual);
		}
		
		return population;
	}
	
}

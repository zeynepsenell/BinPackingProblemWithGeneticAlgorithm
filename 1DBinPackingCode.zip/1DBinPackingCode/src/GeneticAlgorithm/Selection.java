package GeneticAlgorithm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import BinPacking.Item;
/**
 * This class is being created for performing Selection during the genetic algorithm.
 * @author zsenel
 *
 */
public class Selection {
	List<Item> allItems;
	
	Selection(List<Item> allItems){
		this.allItems = allItems;
	}
	
	/**
	 * Performs Stochastic Universal Sampling.
	 * @param population
	 * @param numSelections
	 * @return
	 */
	static List<Individual> susSelection(Population population, int numSelections){
		List<Individual> selectedSolutions = new ArrayList<>();
        double totalFitness = calculateFitnessOfPopulation(population);
        double spaceBetweenPointers = totalFitness / numSelections;
        double startPoint = new Random().nextDouble() * spaceBetweenPointers;

        List<Double> fitnessProportions = new ArrayList<>();
        for (Individual solution : population.getIndividuals()) {
            fitnessProportions.add(solution.getFitness() / totalFitness);
        }
        
        int selectedIndex = 0;
        double fitnessProportionsSum = fitnessProportions.get(0);
        for (int i = 0; i < numSelections; i++) {
            double pointer = startPoint + i * spaceBetweenPointers;
            while (fitnessProportionsSum < pointer && selectedIndex < fitnessProportions.size() - 1) {
                selectedIndex++;
                fitnessProportionsSum += fitnessProportions.get(selectedIndex);
            }
            selectedSolutions.add(population.getIndividuals().get(selectedIndex));
        }
        return selectedSolutions;
	}
	
	/**
	 * Performs roulette wheel selection.
	 * @param population
	 * @param numSelections
	 * @return
	 */
	 static List<Individual> rouletteWheelSelection(Population population, int numSelections){
		 List<Individual> selectedSolutions = new ArrayList<>();
		 double totalFitness = calculateFitnessOfPopulation(population);
		 for (int i = 0; i < numSelections; i++) {
			 double randomValue = new Random().nextDouble() * totalFitness;
			 double fitness = 0.0;
			 for (Individual solution : population.getIndividuals()) {
				 fitness = fitness + solution.getFitness();
				 if (fitness >= randomValue) {
					 selectedSolutions.add(solution);
					 break;
				 }
			 }
		 }
		 return selectedSolutions;
	}
	
	/**
	 * Performs tournament selection.
	 * @param population
	 * @param tournamentSize
	 * @param numParents
	 * @return
	 */
	List<Individual> tournamentSelection(Population population, int tournamentSize,
			int numParents) {
	    List<Individual> parents = new ArrayList<>();
	    List<Individual> individuals = population.getIndividuals();
	    for (int i = 0; i < numParents; i++) {
	    	//Selects randomly individuals for tournament
	        List<Individual> tournamentIndividuals = new ArrayList<>();
	        for (int j = 0; j < tournamentSize; j++) {
	            int randomIndex = new Random().nextInt(individuals.size());
	            tournamentIndividuals.add(individuals.get(randomIndex));
	        }
	        Individual fittest = findFittestIndividual(new Population(tournamentIndividuals, allItems));
	        parents.add(fittest);
	    }
	    return parents;
	}
	
	/**
	 * 
	 * @param population
	 * @return
	 */
	public Individual findFittestIndividual(Population population) {
	    List<Individual> individuals = population.getIndividuals();
	    if (individuals.isEmpty()) {
	        return null;
	    }
	    Individual bestSolution = individuals.get(0);
	    double bestFitness = new Population(Collections.singletonList(bestSolution), allItems)
	    		.calculateFitness().get(0);

	    for (Individual individual : individuals) {
	        double currentFitness = new Population(Collections.singletonList(individual), allItems)
	        		.calculateFitness().get(0);
	        if (currentFitness > bestFitness) {
	            bestSolution = individual;
	            bestFitness = currentFitness;
	        }
	    }
	    return bestSolution;
	}
	
	private static double calculateFitnessOfPopulation(Population population) {
		double totalFitness = 0;
		for(Individual individual : population.getIndividuals()) {
			totalFitness = totalFitness + individual.getFitness();
		}
	    return totalFitness;     
	}
}

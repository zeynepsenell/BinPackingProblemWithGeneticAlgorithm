package GeneticAlgorithm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * This class is for replacement step.
 * @author zsenel
 *
 */
public class Replacement {
	
	Replacement(){
		//Empty constructor
	}
	
	/**
	 * Performs a steady state replacement.
	 * @param initialPopulation
	 * @param offsprings
	 * @param newPopulationSize
	 * @return
	 */
	public List<Individual> steadyStateReplacement(List<Individual> initialPopulation, 
			List<Individual> offsprings, int newPopulationSize) {
	    List<Individual> combined = new ArrayList<>(initialPopulation);
	    combined.addAll(offsprings);
	    //Selects from all combined list individuals with best fitness's.
	    combined.sort((s1, s2) -> Double.compare(s2.getFitness(), s1.getFitness()));
	    return combined.subList(0, newPopulationSize);
	}
	
	/**
	 * Performs elitism replacement
	 * @param initialPopulation
	 * @param offsprings
	 * @param numElites number of elites, that will be stay in the next generation
	 * @return
	 */
	 public List<Individual> elitismReplacement(List<Individual> initialPopulation,
			 List<Individual> offsprings, int numElites) {
		 List<Individual> sortedIndividuals = new ArrayList<>(initialPopulation);
		 //Sorts individuals according to their fitness values.
		 Collections.sort(sortedIndividuals, new Comparator<Individual>() {
			    @Override
			    public int compare(Individual o1, Individual o2) {
			        return Double.compare(o2.getFitness(), o1.getFitness());
			    }
			});
		 // Gets the best individuals
		 List<Individual> elites = new ArrayList<>(sortedIndividuals.subList(0, numElites));
		 List<Individual> newIndividuals = new ArrayList<>();
		 newIndividuals.addAll(elites);
		 newIndividuals.addAll(offsprings);
		 return newIndividuals;
	 }
}

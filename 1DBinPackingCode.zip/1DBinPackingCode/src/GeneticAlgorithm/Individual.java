package GeneticAlgorithm;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import BinPacking.Bin;
import BinPacking.Item;
import BinPacking.ItemBinArrangement;

/**
 * This class represent a possible solution
 * @author zsenel
 *
 */
public class Individual {
	private List<ItemBinArrangement<Integer, Integer>> itemBinArrangements;
	private double fitness;
	private int numberOfBins = 0;
	
	public Individual(List<ItemBinArrangement<Integer,Integer>> itemBinArrangments) {
		this.itemBinArrangements = itemBinArrangments;
	}
	
	/**
	 * Calculates number of bins in an individual
	 * @return
	 */
    public int calculateNumberOfBinsInIndividual() {
        int maxBinIndex = -1;
        for (ItemBinArrangement<Integer, Integer> itemBinArrangement : itemBinArrangements) {
            int binIndex = itemBinArrangement.getBin();
            if (binIndex > maxBinIndex) {
                maxBinIndex = binIndex;
            }
        }
        numberOfBins = maxBinIndex + 1;
        return maxBinIndex + 1;
    }
    
    /**
     * Calculates total waste in a bin
     * @param items
     * @return
     */
    public int getTotalWaste(List<Item> items) {
    	int totalWaste = 0;
    	 Map<Integer, Integer> binUsage = new HashMap<>();
         for (ItemBinArrangement<Integer, Integer> itemBinArrangement : itemBinArrangements) {
             int itemId = itemBinArrangement.getItem();
             int bin = itemBinArrangement.getBin();
             int itemSize = Bin.searchItemWithId(itemId);
             binUsage.put(bin, binUsage.getOrDefault(bin, 0) + itemSize);
         }
         for (int binUsed : binUsage.values()) {
             totalWaste += Bin.capacity - binUsed;
         }
         return totalWaste;
    }
    
	public double getFitness() {
		return fitness;
	}

	public void setFitness(double fitness) {
		this.fitness = fitness;
	}

	public List<ItemBinArrangement<Integer, Integer>> getItemBinArrangment() {
		return itemBinArrangements;
	}

	public void setItemBinArrangment(List<ItemBinArrangement<Integer, Integer>> itemBinArrangments) {
		this.itemBinArrangements = itemBinArrangments;
	}

	public int getNumberOfBins() {
		return numberOfBins;
	}
	
	
}

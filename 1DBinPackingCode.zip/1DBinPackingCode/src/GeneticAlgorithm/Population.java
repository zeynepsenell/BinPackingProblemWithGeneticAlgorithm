package GeneticAlgorithm;

import java.util.ArrayList;
import java.util.List;
import BinPacking.Item;

public class Population {
	private List<Individual> individuals = new ArrayList<>();
	private List<Item> allItems = new ArrayList<>();
	
	Population(List<Item> allItems){
		this.allItems = allItems;
	}
	
    public Population(List<Individual> individuals, List<Item> allItems) {
        this.individuals = individuals;
        this.allItems = allItems;
    }

	public void addIndividual(Individual individual) {
		individuals.add(individual);
	}

	public List<Double> calculateFitness() {
	    List<Double> fitnessValues = new ArrayList<>(individuals.size());
	    //Total waste is also an important feature for calculating fitness.
	    //This is the proportion of waste in the whole fitness value.
	    double wasteWeight = 0.4;
	    for (Individual individual : individuals) {
	        int numberOfBins = individual.calculateNumberOfBinsInIndividual();
	        double totalWaste = individual.getTotalWaste(this.allItems);

	        double fitness = 1.0 / (numberOfBins + (wasteWeight * totalWaste));
	        individual.setFitness(fitness);
	        fitnessValues.add(fitness);
	    }
	    return fitnessValues;
	}

	public List<Individual> getIndividuals() {
		return individuals;
	}

	public void setIndividuals(List<Individual> individuals) {
		this.individuals = individuals;
	}
}

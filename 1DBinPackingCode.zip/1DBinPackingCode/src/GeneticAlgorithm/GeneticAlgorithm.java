package GeneticAlgorithm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import BinPacking.Bin;
import BinPacking.Item;
import BinPacking.ItemBinArrangement;

public class GeneticAlgorithm {
	private int populationSize;
	private static double mutationRate;
	
	//Termination criteria
	private int maxGenerations;
	private int noImprovementGenerations = 300; 
	private int currentGeneration = 0;
	private int generationsWithoutImprovement = 0;
	private int generationContainingBestSolution = 0;
	
	private int replacementSize = 100;
	private String initializationMethod;
	private String selectionMethod;
	private String crossoverMethod;
	private String replacementMethod;
	
	private List<Item> allItems;
	private double bestFitness = 0;
	private Individual fittestIndividual = null;
	
	public GeneticAlgorithm(int populationSize, double mutationRate, int maxGenerations,
			String initializationMethod, String selectionMethod, String crossoverMethod,
			String replacementMethod, List<Item> allItems){
		this.populationSize = populationSize;
		GeneticAlgorithm.mutationRate = mutationRate;
		this.maxGenerations = maxGenerations;
		this.initializationMethod = initializationMethod;
		this.selectionMethod = selectionMethod;
		this.crossoverMethod = crossoverMethod;
		this.replacementMethod = replacementMethod;
		this.allItems = allItems;
	}
	
	/**
	 * Initializes first population according to selected method.
	 */
	public Population performSelectedInitializationMethod() {
		Population firstPopulation;
		switch(initializationMethod) {
		  case "Random Initialization":
			  firstPopulation = PopulationInitializer.initializePopulationRandomly(allItems, populationSize,
						0.1, 0.8);
		    break;
		  case "Best-Fit Initialization":
			  firstPopulation = PopulationInitializer.initializePopulationBestFit(populationSize, allItems);
		    break;
		  case "Next-Fit Initialization":
			  firstPopulation = PopulationInitializer.initializePopulationNextFit(populationSize, allItems);
			  break;
		  default:
			  firstPopulation =PopulationInitializer.initializePopulationRandomly(allItems, populationSize,
						 0.1, 0.8);
		}
		return firstPopulation;
	}
	
	/**
	 * Performs crossover according to selected method.
	 */
	public List<Individual> performSelectedCrossOver(Individual parent1, Individual parent2) {
		Crossover crossover = new Crossover();
		java.util.List<Individual> children;
		List<Individual> validIndividuals = new ArrayList<>();
		Map<Integer, Integer> itemWeights = allItems.stream()
	            .collect(Collectors.toMap(Item::getId, Item::getSize));
		switch(crossoverMethod) {
		  case "One-Point Crossover":
			children = crossover.onePointCrossover(parent1, parent2);
		    for(Individual solution : children) {
		    	if(crossover.isIndividualValid(solution, itemWeights)) {
		    		validIndividuals.add(solution);
		    	}
		    }
		    children = validIndividuals;
		    break;
		  case "Two-Point Crossover":
			children = crossover.twoPointCrossover(parent1, parent2); 
			for(Individual solution : children) {
		    	if(crossover.isIndividualValid(solution, itemWeights)) {
		    		validIndividuals.add(solution);
		    	}
		    }
		    children = validIndividuals;
		    break;
		  default:
			children = crossover.onePointCrossover(parent1, parent2);
			for(Individual solution : children) {
		    	if(crossover.isIndividualValid(solution, itemWeights)) {
		    		validIndividuals.add(solution);
		    	}
		    }
		    children = validIndividuals;
		}
		return children;
	}
	
	/**
	 * Performs selection according to selected method.
	 */
	public List<Individual> performSelectedSelectionMethod(Population firstPopulation) {
		Selection selection = new Selection(allItems);
		List<Individual> parents;
		switch(selectionMethod) {
		  case "Tournament Selection":
			parents = selection.tournamentSelection
				(firstPopulation, 5, 40);
		    break;
		  case "Roulette Wheel Selection":
			parents = Selection.rouletteWheelSelection(firstPopulation, firstPopulation.getIndividuals().size());
		    break;
		  case "SUS":
			parents = Selection.susSelection(firstPopulation, firstPopulation.getIndividuals().size());
			break;
		  default:
			  parents =selection.tournamentSelection(firstPopulation, 5, 40);
		}
		return parents;
	}
	
	public List<Individual> performSelectedReplacementMethod(List<Individual> initialPopulationIndividuals,
			List<Individual> offsprings) {
		Replacement replacement = new Replacement();
		List<Individual> newPopulation;
		switch(replacementMethod) {
		  case "Steady-State Replacement":
			newPopulation = replacement.steadyStateReplacement(initialPopulationIndividuals, offsprings, replacementSize);
		    break;
		  case "Elitism":
			newPopulation = replacement.elitismReplacement(initialPopulationIndividuals, offsprings, 5);
		    break;
		  default:
			newPopulation = replacement.steadyStateReplacement(initialPopulationIndividuals, offsprings, replacementSize);
		}
		return newPopulation;
	}
	
	public static Individual mutateSolution(Individual individual, List<Item> items) {
		//All bins are generated
	    Map<Integer, List<Item>> bins = generateBinsFromArrangement(individual, items); 

	    for (int bin : bins.keySet()) {
	        List<Item> itemsInBin = bins.get(bin);
	        for (int i = 0; i < itemsInBin.size(); i++) {
	            if (new Random().nextDouble() < GeneticAlgorithm.mutationRate) {
	                List<Integer> differentBins = new ArrayList<>(bins.keySet());
	                //Current bin is removed from bin list
	                differentBins.remove((Integer) bin);
	                //A different bin is chosen
	                int idNewBin = differentBins.get(new Random().nextInt(differentBins.size()));
	                Item itemToMove = itemsInBin.get(i);
	                
	                int totalWeight = 0;
	                for (Item item : bins.get(idNewBin)) {
	                    totalWeight += item.getSize();
	                }
	                //Item will be added to the other bin, if the capacity is not exceeded
	                if (totalWeight + itemToMove.getSize() <= Bin.capacity) {
	                    bins.get(idNewBin).add(itemToMove);
	                    itemsInBin.remove(i);
	                    i--;
	                }
	            }
	        }
	    }
	    return createMutatedIndividual(bins);
	}
	
	/**
	 * Creates a new individual with mutated bins.
	 * @param bins
	 * @return
	 */
	private static Individual createMutatedIndividual(Map<Integer, List<Item>> bins) {
		List<ItemBinArrangement<Integer, Integer>> mutatedGenes = new ArrayList<>();
	    for (int bin : bins.keySet()) {
	        for (Item item : bins.get(bin)) {
	            mutatedGenes.add(new ItemBinArrangement<>(item.getId(), bin));
	        }
	    }
	    return new Individual(mutatedGenes);
	}
	
	/**
	 * Generates bins from individual's genes.
	 * @param individual
	 * @param items
	 * @return
	 */
	private static Map<Integer, List<Item>> generateBinsFromArrangement(Individual individual, List<Item> items) {
		Map<Integer, List<Item>> bins = new HashMap<>();
		for (ItemBinArrangement<Integer, Integer> itemBinArrangement : individual.getItemBinArrangment()) {
	        int itemId = itemBinArrangement.getItem();
	        int binId = itemBinArrangement.getBin();

	        Item currentItem = null;
	        for (Item item : items) {
	            if (item.getId() == itemId) {
	                currentItem = item;
	                break;
	            }
	        }

	        bins.putIfAbsent(binId, new ArrayList<>());
	        bins.get(binId).add(currentItem);
	    }
		return bins;
	}
		
	public void checkForImprovement(Population newPopulation, Double bestFitnessOfNewPopulation) {
		if (bestFitnessOfNewPopulation > bestFitness) {
	        bestFitness = bestFitnessOfNewPopulation;
	        fittestIndividual = Collections.max(newPopulation.getIndividuals(), 
	        		Comparator.comparing(Individual::getFitness));
	        generationContainingBestSolution = currentGeneration;
	        generationsWithoutImprovement = 0;
	    } else {
	        generationsWithoutImprovement++;
	    }
	}

	public boolean isTerminationCriteriaFilled() {
		return generationsWithoutImprovement < noImprovementGenerations && currentGeneration < maxGenerations;
	}

	public int getCurrentGeneration() {
		return currentGeneration;
	}

	public void setCurrentGeneration(int currentGeneration) {
		this.currentGeneration = currentGeneration;
	}
	
	public void setGenerationContainingBestSolution(int generationContainingBestSolution) {
		this.generationContainingBestSolution = generationContainingBestSolution;
	}

	public int getGenerationContainingBestSolution() {
		return generationContainingBestSolution;
	}

	public Individual getFittestIndividual() {
		return fittestIndividual;
	}

	public double getBestFitness() {
		return bestFitness;
	}

	public void setBestFitness(double bestFitness) {
		this.bestFitness = bestFitness;
	}

	public void setFittestIndividual(Individual fittestIndividual) {
		this.fittestIndividual = fittestIndividual;
	}

	public void setGenerationsWithoutImprovement(int generationsWithoutImprovement) {
		this.generationsWithoutImprovement = generationsWithoutImprovement;
	}
	
	
}

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

import BinPacking.Bin;
import GeneticAlgorithm.GeneticAlgorithm;
import GeneticAlgorithm.Individual;
import GeneticAlgorithm.Population;
import view.BinPackingOptionsPanel;
import view.SolutionDrawer;

public class GeneticAlgorithmRunner {
	private static DataReader reader = new DataReader();
	private static BinPackingOptionsPanel view;
	private static GeneticAlgorithm geneticAlgorithm;
	private static SolutionDrawerWithScrollPane solutionDrawer;
	private static JLabel solutionFoundLabel;
	private static long startTime;
	private static long endTime;
	
	public static void main(String[] args) {
		view = new BinPackingOptionsPanel();
		view.setVisible(true);
		view.getAlgorithmStarterButton().addActionListener(new ActionListener() { 
        	  public void actionPerformed(ActionEvent e) { 
        		  view.getGlassPane().setVisible(true);
        		  SwingWorker<Void, Void> task = new SwingWorker<Void, Void>() {
        			  @Override
        			  //Performs the genetic algorithm in the background 
        			  //without disturbing user interface
        			  protected Void doInBackground() {
        				  //First clears the last solution
        				  if(solutionDrawer != null) {
            				  view.getSolutionPanel().remove(solutionDrawer);
            				  view.getSolutionPanel().remove(solutionFoundLabel);
            				  reader.getCounter().set(0);
            				  Bin.items.clear();
            				  reader.allItems.clear();
        				  }
        				  //Stars to finding a solution
        				  startTime = System.nanoTime();
        				  Bin.capacity = Integer.parseInt(view.getBinSizeField().getText());
        				  reader.readData(view.getFilePathField().getText());
        				  startGeneticAlgorithm();
        				  return null;
        			  }
        			  @Override
        			  protected void done() {
        				  //After the genetic algorithm is done, glasspane disappears
        				  view.getGlassPane().setVisible(false);
        			  }
        		  };
        		  task.execute();
        	  }
        });
	}
	
	private static void startGeneticAlgorithm() {
		geneticAlgorithm = new GeneticAlgorithm(Integer.parseInt(view.getPopulationSizeField().getText()),
				Double.parseDouble(view.getMutationRateField().getText()),
				Integer.parseInt(view.getMaxGenerationsField().getText()),
				view.getInitalizationMethods().getSelectedItem().toString(),
				view.getSelectionMethods().getSelectedItem().toString(),
				view.getCrossoverMethods().getSelectedItem().toString(),
				view.getReplacementMethods().getSelectedItem().toString(),
				reader.getAllItems());
		//Creates the first population
		Population firstPopulation = geneticAlgorithm.performSelectedInitializationMethod();
		//Checks if the termination criteria is filled
		while(geneticAlgorithm.isTerminationCriteriaFilled()) {
			System.out.println("Generation: " + geneticAlgorithm.getCurrentGeneration() 
			+ ", Best fitness: " + String.format("%.16f", geneticAlgorithm.getBestFitness()));
			//Calculates the fitness of created population
			firstPopulation.calculateFitness();
			//Selects individuals from first population according to the selection method
			java.util.List<Individual> parents = geneticAlgorithm.performSelectedSelectionMethod(firstPopulation); 
			//Performs crossover
			java.util.List<Individual> offspring = new ArrayList<>();
			double crossoverProbability = Double.parseDouble(view.getCrossoverRateField().getText());
			for (int i = 0; i < parents.size() / 2; i++) {
				Individual parent1 = parents.get(2 * i);
				Individual parent2 = parents.get(2 * i + 1);

				//Checks if a random number is smaller than the crossover rate, if yes performs crossover
				if (Math.random() < crossoverProbability) {
					java.util.List<Individual> children = geneticAlgorithm.performSelectedCrossOver(parent1, parent2);
					offspring.addAll(children);
			    } else {
			    	offspring.add(parent1);
			    	offspring.add(parent2);
			    }
			}

			//Creates a population after crossover with offsprings
			Population populationAfterCrossover = new Population(offspring, reader.allItems);
			populationAfterCrossover.calculateFitness();

			//Mutation
			List<Individual> mutatedOffspring = new ArrayList<>();
			for (Individual individual : offspring) {
				Individual result = GeneticAlgorithm.mutateSolution(individual, reader.allItems);
				mutatedOffspring.add(result);
			}
			
			//Creates a population using mutated offsprings
			Population populationAfterMutation = new Population(mutatedOffspring, reader.allItems);
			populationAfterMutation.calculateFitness();
			//Performs replacement
			java.util.List<Individual> newPopulationIndividuals = geneticAlgorithm
					.performSelectedReplacementMethod(firstPopulation.getIndividuals(), mutatedOffspring);
			//Creates new population and calculates fitness values
			Population newPopulation = new Population(newPopulationIndividuals,reader.allItems);
			java.util.List<Double> newFitnesses = newPopulation.calculateFitness();
			//Gets the best fitness of new population to check if there is an improvement
			double newBestFitness = Collections.max(newFitnesses);
			geneticAlgorithm.checkForImprovement(newPopulation, newBestFitness);
			//Replaces firstPopulation with newly created one
			firstPopulation = newPopulation;
			geneticAlgorithm.setCurrentGeneration(geneticAlgorithm.getCurrentGeneration() + 1);
		}
		//After the while loop, draws the fittest solution
		drawSolution(geneticAlgorithm.getFittestIndividual());
		System.out.println(geneticAlgorithm.getGenerationContainingBestSolution());
		double elapsedTimeInSeconds = (endTime - startTime) / 1_000_000_000.0;
		System.out.println("Solution found in " + elapsedTimeInSeconds + 
				 " seconds. Total number of bins: " + geneticAlgorithm.getFittestIndividual().getNumberOfBins());
	}
	
	/**
	 * Draws solution
	 * @param bestSolution solution with the highest fitness value
	 */
	private static void drawSolution(Individual bestSolution) {
		 SwingUtilities.invokeLater(() -> {
			 solutionDrawer = new SolutionDrawerWithScrollPane(bestSolution);
			 view.getGlassPane().setVisible(false);
			 view.getSolutionPanel().add(solutionDrawer,BorderLayout.CENTER);
		 });
		 endTime = System.nanoTime();
		 double elapsedTimeInSeconds = (endTime - startTime) / 1_000_000_000.0;
		 solutionFoundLabel = new JLabel("Solution found in " + elapsedTimeInSeconds + 
				 " seconds. Total number of bins: " + bestSolution.getNumberOfBins());
		 view.getSolutionPanel().add(solutionFoundLabel,BorderLayout.NORTH);
	}
}

class SolutionDrawerWithScrollPane extends JPanel {
	private static final long serialVersionUID = 1L;
	private SolutionDrawer binDrawer;
    private JScrollPane scrollPane;

    public SolutionDrawerWithScrollPane(Individual bestSolution) {
        this.setLayout(new BorderLayout());
        this.binDrawer = new SolutionDrawer(bestSolution);
        this.scrollPane = new JScrollPane(binDrawer);
        this.add(scrollPane, BorderLayout.CENTER);
    }
}
